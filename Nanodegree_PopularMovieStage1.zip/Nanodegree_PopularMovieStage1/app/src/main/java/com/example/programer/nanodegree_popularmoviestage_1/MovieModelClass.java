package com.example.programer.nanodegree_popularmoviestage_1;

public class MovieModelClass {
    String mTitle;
    int mPoster;
    String mRating;
    String mReleaseDate;
    String mSynopsis;

    public MovieModelClass(String mTitle, int mPoster, String mRating, String mReleaseDate, String mSynopsis) {
        this.mTitle = mTitle;
        this.mPoster = mPoster;
        this.mRating = mRating;
        this.mReleaseDate = mReleaseDate;
        this.mSynopsis = mSynopsis;
    }

    public String getmTitle() {
        return mTitle;
    }

    public int getmPoster() {
        return mPoster;
    }

    public String getmRating() {
        return mRating;
    }

    public String getmReleaseDate() {
        return mReleaseDate;
    }

    public String getmSynopsis() {
        return mSynopsis;
    }
}
