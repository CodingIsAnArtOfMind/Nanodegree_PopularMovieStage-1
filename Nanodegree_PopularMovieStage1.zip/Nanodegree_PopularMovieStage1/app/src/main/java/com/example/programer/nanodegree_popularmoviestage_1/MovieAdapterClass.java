package com.example.programer.nanodegree_popularmoviestage_1;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class MovieAdapterClass extends ArrayAdapter<MovieModelClass> {
    public MovieAdapterClass(@NonNull Activity context, List<MovieModelClass> movieModelClass) {
        super(context, 0, movieModelClass);
    }


    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        MovieModelClass movieModel = getItem(position);
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(
                    R.layout.movielayout, parent, false);
        }
        TextView titlePoster = (TextView)convertView.findViewById(R.id.poster_title);
        titlePoster.setText(movieModel.mTitle);
        ImageView posterImage =(ImageView)convertView.findViewById(R.id.poster_image);
        posterImage.setImageResource(movieModel.mPoster);
        TextView rating = (TextView)convertView.findViewById(R.id.user_rating);
        titlePoster.setText(movieModel.mRating);
        TextView releaseDate = (TextView)convertView.findViewById(R.id.release_date);
        titlePoster.setText(movieModel.mReleaseDate);
        TextView synopsis = (TextView)convertView.findViewById(R.id.synopsis);
        titlePoster.setText(movieModel.mSynopsis);
        return convertView;
    }
}
