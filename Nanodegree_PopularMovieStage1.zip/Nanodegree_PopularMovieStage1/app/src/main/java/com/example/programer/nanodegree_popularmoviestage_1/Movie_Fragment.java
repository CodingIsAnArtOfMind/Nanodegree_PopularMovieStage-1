package com.example.programer.nanodegree_popularmoviestage_1;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;

import java.util.Arrays;


/**
 * A simple {@link Fragment} subclass.
 */
public class Movie_Fragment extends Fragment {
    private MovieAdapterClass movieAdapterClass;
    MovieModelClass[] listMovie = {
            new MovieModelClass("Android", R.drawable.ic_launcher_background, "4.2",
            "14/10/15", "It is an Open Source")
};


    public Movie_Fragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootview = inflater.inflate(R.layout.fragment_movie_, container, false);
        movieAdapterClass = new MovieAdapterClass(getActivity(), Arrays.asList(listMovie));
        GridView gridView = (GridView) rootview.findViewById(R.id.gridView);
        gridView.setAdapter(movieAdapterClass);

        return rootview;
    }

}
